<?php
// created: 2018-10-15 21:58:00
$dictionary["acc_CustomerBankAccount"]["fields"]["acc_customerbankaccount_tra_customertransaction"] = array (
  'name' => 'acc_customerbankaccount_tra_customertransaction',
  'type' => 'link',
  'relationship' => 'acc_customerbankaccount_tra_customertransaction',
  'source' => 'non-db',
  'module' => 'tra_CustomerTransaction',
  'bean_name' => 'tra_CustomerTransaction',
  'side' => 'right',
  'vname' => 'LBL_ACC_CUSTOMERBANKACCOUNT_TRA_CUSTOMERTRANSACTION_FROM_TRA_CUSTOMERTRANSACTION_TITLE',
);
