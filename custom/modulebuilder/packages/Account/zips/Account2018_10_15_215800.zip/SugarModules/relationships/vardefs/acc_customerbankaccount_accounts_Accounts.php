<?php
// created: 2018-10-15 21:58:00
$dictionary["Account"]["fields"]["acc_customerbankaccount_accounts"] = array (
  'name' => 'acc_customerbankaccount_accounts',
  'type' => 'link',
  'relationship' => 'acc_customerbankaccount_accounts',
  'source' => 'non-db',
  'module' => 'acc_CustomerBankAccount',
  'bean_name' => 'acc_CustomerBankAccount',
  'side' => 'right',
  'vname' => 'LBL_ACC_CUSTOMERBANKACCOUNT_ACCOUNTS_FROM_ACC_CUSTOMERBANKACCOUNT_TITLE',
);
