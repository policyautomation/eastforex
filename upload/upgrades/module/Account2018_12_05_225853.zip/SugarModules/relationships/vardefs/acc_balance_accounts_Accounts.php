<?php
// created: 2018-12-05 22:58:53
$dictionary["Account"]["fields"]["acc_balance_accounts"] = array (
  'name' => 'acc_balance_accounts',
  'type' => 'link',
  'relationship' => 'acc_balance_accounts',
  'source' => 'non-db',
  'module' => 'acc_Balance',
  'bean_name' => 'acc_Balance',
  'side' => 'right',
  'vname' => 'LBL_ACC_BALANCE_ACCOUNTS_FROM_ACC_BALANCE_TITLE',
);
