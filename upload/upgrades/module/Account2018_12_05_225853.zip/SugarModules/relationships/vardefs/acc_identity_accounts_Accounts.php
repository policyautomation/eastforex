<?php
// created: 2018-12-05 22:58:53
$dictionary["Account"]["fields"]["acc_identity_accounts"] = array (
  'name' => 'acc_identity_accounts',
  'type' => 'link',
  'relationship' => 'acc_identity_accounts',
  'source' => 'non-db',
  'module' => 'acc_Identity',
  'bean_name' => 'acc_Identity',
  'side' => 'right',
  'vname' => 'LBL_ACC_IDENTITY_ACCOUNTS_FROM_ACC_IDENTITY_TITLE',
);
