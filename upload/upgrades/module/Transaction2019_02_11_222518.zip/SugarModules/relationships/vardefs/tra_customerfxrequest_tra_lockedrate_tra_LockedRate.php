<?php
// created: 2019-02-11 22:25:16
$dictionary["tra_LockedRate"]["fields"]["tra_customerfxrequest_tra_lockedrate"] = array (
  'name' => 'tra_customerfxrequest_tra_lockedrate',
  'type' => 'link',
  'relationship' => 'tra_customerfxrequest_tra_lockedrate',
  'source' => 'non-db',
  'module' => 'tra_CustomerFXRequest',
  'bean_name' => 'tra_CustomerFXRequest',
  'side' => 'right',
  'vname' => 'LBL_TRA_CUSTOMERFXREQUEST_TRA_LOCKEDRATE_FROM_TRA_CUSTOMERFXREQUEST_TITLE',
);
