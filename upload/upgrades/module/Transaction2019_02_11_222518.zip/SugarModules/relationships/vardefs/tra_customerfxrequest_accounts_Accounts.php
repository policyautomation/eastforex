<?php
// created: 2019-02-11 22:25:16
$dictionary["Account"]["fields"]["tra_customerfxrequest_accounts"] = array (
  'name' => 'tra_customerfxrequest_accounts',
  'type' => 'link',
  'relationship' => 'tra_customerfxrequest_accounts',
  'source' => 'non-db',
  'module' => 'tra_CustomerFXRequest',
  'bean_name' => 'tra_CustomerFXRequest',
  'side' => 'right',
  'vname' => 'LBL_TRA_CUSTOMERFXREQUEST_ACCOUNTS_FROM_TRA_CUSTOMERFXREQUEST_TITLE',
);
