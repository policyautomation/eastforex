<?php
// created: 2019-02-11 22:25:16
$dictionary["tra_EFFXRequest"]["fields"]["tra_effxrequest_tra_eftransaction"] = array (
  'name' => 'tra_effxrequest_tra_eftransaction',
  'type' => 'link',
  'relationship' => 'tra_effxrequest_tra_eftransaction',
  'source' => 'non-db',
  'module' => 'tra_EFTransaction',
  'bean_name' => 'tra_EFTransaction',
  'side' => 'right',
  'vname' => 'LBL_TRA_EFFXREQUEST_TRA_EFTRANSACTION_FROM_TRA_EFTRANSACTION_TITLE',
);
