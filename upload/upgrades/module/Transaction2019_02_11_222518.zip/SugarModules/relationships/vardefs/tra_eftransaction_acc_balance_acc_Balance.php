<?php
// created: 2019-02-11 22:25:17
$dictionary["acc_Balance"]["fields"]["tra_eftransaction_acc_balance"] = array (
  'name' => 'tra_eftransaction_acc_balance',
  'type' => 'link',
  'relationship' => 'tra_eftransaction_acc_balance',
  'source' => 'non-db',
  'module' => 'tra_EFTransaction',
  'bean_name' => 'tra_EFTransaction',
  'side' => 'right',
  'vname' => 'LBL_TRA_EFTRANSACTION_ACC_BALANCE_FROM_TRA_EFTRANSACTION_TITLE',
);
