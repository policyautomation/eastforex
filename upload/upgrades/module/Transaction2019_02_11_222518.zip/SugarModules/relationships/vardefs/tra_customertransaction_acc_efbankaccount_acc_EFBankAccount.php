<?php
// created: 2019-02-11 22:25:17
$dictionary["acc_EFBankAccount"]["fields"]["tra_customertransaction_acc_efbankaccount"] = array (
  'name' => 'tra_customertransaction_acc_efbankaccount',
  'type' => 'link',
  'relationship' => 'tra_customertransaction_acc_efbankaccount',
  'source' => 'non-db',
  'module' => 'tra_CustomerTransaction',
  'bean_name' => 'tra_CustomerTransaction',
  'side' => 'right',
  'vname' => 'LBL_TRA_CUSTOMERTRANSACTION_ACC_EFBANKACCOUNT_FROM_TRA_CUSTOMERTRANSACTION_TITLE',
);
