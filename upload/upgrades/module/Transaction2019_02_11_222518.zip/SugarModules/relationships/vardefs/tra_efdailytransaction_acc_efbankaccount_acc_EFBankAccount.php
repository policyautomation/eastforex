<?php
// created: 2019-02-11 22:25:17
$dictionary["acc_EFBankAccount"]["fields"]["tra_efdailytransaction_acc_efbankaccount"] = array (
  'name' => 'tra_efdailytransaction_acc_efbankaccount',
  'type' => 'link',
  'relationship' => 'tra_efdailytransaction_acc_efbankaccount',
  'source' => 'non-db',
  'module' => 'tra_EFTransaction',
  'bean_name' => 'tra_EFTransaction',
  'side' => 'right',
  'vname' => 'LBL_TRA_EFDAILYTRANSACTION_ACC_EFBANKACCOUNT_FROM_TRA_EFTRANSACTION_TITLE',
);
