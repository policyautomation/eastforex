<?php
// created: 2019-02-11 22:25:17
$dictionary["acc_CustomerBankAccount"]["fields"]["tra_customertransaction_acc_customerbankaccount"] = array (
  'name' => 'tra_customertransaction_acc_customerbankaccount',
  'type' => 'link',
  'relationship' => 'tra_customertransaction_acc_customerbankaccount',
  'source' => 'non-db',
  'module' => 'tra_CustomerTransaction',
  'bean_name' => 'tra_CustomerTransaction',
  'side' => 'right',
  'vname' => 'LBL_TRA_CUSTOMERTRANSACTION_ACC_CUSTOMERBANKACCOUNT_FROM_TRA_CUSTOMERTRANSACTION_TITLE',
);
