<?php
// created: 2019-02-11 22:25:16
$dictionary["tra_CustomerFXRequest"]["fields"]["tra_customerfxrequest_tra_customertransaction"] = array (
  'name' => 'tra_customerfxrequest_tra_customertransaction',
  'type' => 'link',
  'relationship' => 'tra_customerfxrequest_tra_customertransaction',
  'source' => 'non-db',
  'module' => 'tra_CustomerTransaction',
  'bean_name' => 'tra_CustomerTransaction',
  'side' => 'right',
  'vname' => 'LBL_TRA_CUSTOMERFXREQUEST_TRA_CUSTOMERTRANSACTION_FROM_TRA_CUSTOMERTRANSACTION_TITLE',
);
