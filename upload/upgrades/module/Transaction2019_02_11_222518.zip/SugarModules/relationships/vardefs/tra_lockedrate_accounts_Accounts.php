<?php
// created: 2019-02-11 22:25:17
$dictionary["Account"]["fields"]["tra_lockedrate_accounts"] = array (
  'name' => 'tra_lockedrate_accounts',
  'type' => 'link',
  'relationship' => 'tra_lockedrate_accounts',
  'source' => 'non-db',
  'module' => 'tra_LockedRate',
  'bean_name' => 'tra_LockedRate',
  'side' => 'right',
  'vname' => 'LBL_TRA_LOCKEDRATE_ACCOUNTS_FROM_TRA_LOCKEDRATE_TITLE',
);
