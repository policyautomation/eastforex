<?php
// created: 2019-02-11 22:25:17
$dictionary["Account"]["fields"]["tra_customertransaction_accounts"] = array (
  'name' => 'tra_customertransaction_accounts',
  'type' => 'link',
  'relationship' => 'tra_customertransaction_accounts',
  'source' => 'non-db',
  'module' => 'tra_CustomerTransaction',
  'bean_name' => 'tra_CustomerTransaction',
  'side' => 'right',
  'vname' => 'LBL_TRA_CUSTOMERTRANSACTION_ACCOUNTS_FROM_TRA_CUSTOMERTRANSACTION_TITLE',
);
