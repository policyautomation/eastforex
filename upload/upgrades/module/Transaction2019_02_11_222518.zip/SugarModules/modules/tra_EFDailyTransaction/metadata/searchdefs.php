<?php
$module_name = 'tra_EFDailyTransaction';
$searchdefs [$module_name] = 
array (
  'layout' => 
  array (
    'basic_search' => 
    array (
      'transaction_date' => 
      array (
        'type' => 'date',
        'label' => 'LBL_TRANSACTION_DATE',
        'width' => '10%',
        'default' => true,
        'name' => 'transaction_date',
      ),
      'transaction_type' => 
      array (
        'type' => 'enum',
        'studio' => 'visible',
        'label' => 'LBL_TRANSACTION_TYPE',
        'width' => '10%',
        'default' => true,
        'name' => 'transaction_type',
      ),
      'status' => 
      array (
        'type' => 'enum',
        'studio' => 'visible',
        'label' => 'LBL_STATUS',
        'width' => '10%',
        'default' => true,
        'name' => 'status',
      ),
      'bank_reference_number' => 
      array (
        'type' => 'varchar',
        'label' => 'LBL_BANK_REFERENCE_NUMBER',
        'width' => '10%',
        'default' => true,
        'name' => 'bank_reference_number',
      ),
    ),
    'advanced_search' => 
    array (
      'transaction_date' => 
      array (
        'type' => 'date',
        'label' => 'LBL_TRANSACTION_DATE',
        'width' => '10%',
        'default' => true,
        'name' => 'transaction_date',
      ),
      'transaction_type' => 
      array (
        'type' => 'enum',
        'studio' => 'visible',
        'label' => 'LBL_TRANSACTION_TYPE',
        'width' => '10%',
        'default' => true,
        'name' => 'transaction_type',
      ),
      'status' => 
      array (
        'type' => 'enum',
        'studio' => 'visible',
        'label' => 'LBL_STATUS',
        'width' => '10%',
        'default' => true,
        'name' => 'status',
      ),
      'bank_reference_number' => 
      array (
        'type' => 'varchar',
        'label' => 'LBL_BANK_REFERENCE_NUMBER',
        'width' => '10%',
        'default' => true,
        'name' => 'bank_reference_number',
      ),
      'currency' => 
      array (
        'type' => 'enum',
        'studio' => 'visible',
        'label' => 'LBL_CURRENCY',
        'width' => '10%',
        'default' => true,
        'name' => 'currency',
      ),
      'term' => 
      array (
        'type' => 'enum',
        'studio' => 'visible',
        'label' => 'LBL_TERM',
        'width' => '10%',
        'default' => true,
        'name' => 'term',
      ),
      'tra_efdailytransaction_acc_efbankaccount_name' => 
      array (
        'type' => 'relate',
        'link' => true,
        'label' => 'LBL_TRA_EFDAILYTRANSACTION_ACC_EFBANKACCOUNT_FROM_ACC_EFBANKACCOUNT_TITLE',
        'id' => 'TRA_EFDAILYTRANSACTION_ACC_EFBANKACCOUNTACC_EFBANKACCOUNT_IDA',
        'width' => '10%',
        'default' => true,
        'name' => 'tra_efdailytransaction_acc_efbankaccount_name',
      ),
    ),
  ),
  'templateMeta' => 
  array (
    'maxColumns' => '3',
    'maxColumnsBasic' => '4',
    'widths' => 
    array (
      'label' => '10',
      'field' => '30',
    ),
  ),
);
;
?>
